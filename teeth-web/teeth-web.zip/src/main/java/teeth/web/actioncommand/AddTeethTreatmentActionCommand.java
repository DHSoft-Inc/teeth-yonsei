/* 안쓰는 코드
package teeth.web.actioncommand;
 


import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;

import teeth.service.TreatmentHistoryLocalServiceUtil;
import teeth.web.constants.TeethWebPortletKeys;


@Component(
property = {
	    "javax.portlet.name="+ TeethWebPortletKeys.TEETHWEB,
	    "mvc.command.name=/add_tooth_treatment"
},
service = MVCActionCommand.class
)
public class AddTeethTreatmentActionCommand extends BaseMVCActionCommand {
	
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		// TODO Auto-generated method stub
		
		Date EditedDate = new Date(); 
		
		long patientId = ParamUtil.getLong(actionRequest, "patientId");
		Date treatmentDate = ParamUtil.getDate(actionRequest, "treatmentDate", new SimpleDateFormat("yyyy-MM-dd"));
		String mainCategory = ParamUtil.getString(actionRequest, "mainCategory");
		String selectedStatus = ParamUtil.getString(actionRequest, "selectedStatus");
		long selectedTeeth = ParamUtil.getLong(actionRequest, "selectedTeeth");
		
		TreatmentHistoryLocalServiceUtil.AddHistory(patientId, selectedTeeth, treatmentDate, treatment, state, EditedDate, editedUserID)
	}

}
*/