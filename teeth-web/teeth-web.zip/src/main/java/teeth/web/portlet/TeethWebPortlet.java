package teeth.web.portlet;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;

import java.util.List;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import teeth.model.TreatmentHistory;
import teeth.service.TreatmentHistoryLocalServiceUtil;
import teeth.web.constants.TeethWebPortletKeys;

/**
 * @author User
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=TeethWeb",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/teeth/view/teethview.jsp",
		"javax.portlet.name=" + TeethWebPortletKeys.TEETHWEB,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class TeethWebPortlet extends MVCPortlet {
	
	@Override
    public void render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		try 
		{
			long PatientID = 1001; //임시 PatientID
			List<TreatmentHistory> HistoryList = TreatmentHistoryLocalServiceUtil.getPatientTreatmentList(PatientID);
			renderRequest.setAttribute("patientID", PatientID);
			renderRequest.setAttribute("HistoryList", HistoryList);
			super.render(renderRequest, renderResponse);
		}
		catch(Exception e)
		{
			
		}
	}

}