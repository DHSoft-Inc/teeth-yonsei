package teeth.web.rendercommand;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import teeth.web.constants.TeethWebPortletKeys;


@Component(
	    immediate = true,
	    property = {
	        "javax.portlet.name=" + TeethWebPortletKeys.TEETHWEB,
	        "mvc.command.name=/teeth/view"
	    },
	    service = MVCRenderCommand.class
	)
public class TeethViewRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// TODO Auto-generated method stub
		return "/teeth/view/teethview.jsp";
	}

}
