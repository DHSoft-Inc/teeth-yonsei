package teeth.web.rendercommand;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import teeth.model.TreatmentHistory;
import teeth.service.TreatmentHistoryLocalServiceUtil;
import teeth.web.constants.TeethWebPortletKeys;


@Component(
	    immediate = true,
	    property = {
	        "javax.portlet.name=" + TeethWebPortletKeys.TEETHWEB,
	        "mvc.command.name=/teeth/historyPopup"
	    },
	    service = MVCRenderCommand.class
	)
public class HistoryPopupRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		
        String regionName = ParamUtil.getString(renderRequest, "regionName");
        long patientID = ParamUtil.getLong(renderRequest, "PatientID");
        _log.info("regionName: " + regionName);
        long teethNum = Long.parseLong(regionName.replace("Teeth", ""));
        _log.info("teethNum:" + teethNum);
        List<TreatmentHistory> treatmenthistory = TreatmentHistoryLocalServiceUtil.getPatientTreatmentListByTeethNum(patientID, teethNum);
        _log.info("List: " + treatmenthistory);
       
        List<DisplayHistory> displayList = buildDisplayHistoryList(treatmenthistory);
        _log.info("DisplayList: " + displayList);
        
        renderRequest.setAttribute("displayList", displayList);
        renderRequest.setAttribute("regionName", regionName);
        return "/teeth/view/historyPopup.jsp";
		
	}
	
    /**
     * TreatmentHistory 리스트를 treatmentDate 기준으로 묶어서
     * List<DisplayHistory> 형태로 변환합니다.
     */
    private List<DisplayHistory> buildDisplayHistoryList(List<TreatmentHistory> histories) {
        // TreeMap을 쓰면 날짜 순으로 정렬됩니다.
        Map<Date, DisplayHistory> map = new TreeMap<>();

        for (TreatmentHistory h : histories) {
            Date date = h.getTreatmentDate();
            DisplayHistory dh = map.get(date);

            if (dh == null) {
                dh = new DisplayHistory();
                dh.setDate(date);
                dh.setTreatmentIDList("");
                dh.setTreatmnetStringList("");
                dh.setStatus("");
                map.put(date, dh);
            }

            // 1) TreatmentIDList
            if (dh.getTreatmentIDList().isEmpty()) {
                dh.setTreatmentIDList(String.valueOf(h.getTreatmentID()));
            } else {
                dh.setTreatmentIDList(dh.getTreatmentIDList() + "," + h.getTreatmentID());
            }

            // 2) TreatmnetStringList
            if (h.getTreatment() != null && !h.getTreatment().isEmpty()) {
                if (dh.getTreatmnetStringList().isEmpty()) {
                    dh.setTreatmnetStringList(h.getTreatment());
                } else {
                    dh.setTreatmnetStringList(dh.getTreatmnetStringList() + "," + h.getTreatment());
                }
            }

            // 3) Status (state 컬럼)
            // 첫 번째 non-empty 상태만 설정
            if ((dh.getStatus() == null || dh.getStatus().isEmpty())
                && h.getState() != null && !h.getState().isEmpty()) {
                dh.setStatus(h.getState());
            }
        }

        return new ArrayList<>(map.values());
    }
	
	
	public class DisplayHistory
	{
		String TreatmentIDList; //
		String TreatmnetStringList;
		Date Date;
		String Status;
		
	    // TreatmentIDList
	    public String getTreatmentIDList() {
	        return TreatmentIDList;
	    }

	    public void setTreatmentIDList(String treatmentIDList) {
	        this.TreatmentIDList = treatmentIDList;
	    }

	    // TreatmnetStringList
	    public String getTreatmnetStringList() {
	        return TreatmnetStringList;
	    }

	    public void setTreatmnetStringList(String treatmnetStringList) {
	        this.TreatmnetStringList = treatmnetStringList;
	    }

	    // Date
	    public Date getDate() {
	        return Date;
	    }

	    public void setDate(Date date) {
	        this.Date = date;
	    }

	    // Status
	    public String getStatus() {
	        return Status;
	    }

	    public void setStatus(String status) {
	        this.Status = status;
	    }
		
	}
	
	Log _log = LogFactoryUtil.getLog(HistoryPopupRenderCommand.class);

}
