package teeth.web.constants;

/**
 * @author User
 */
public class TeethWebPortletKeys {

	public static final String TEETHWEB =
		"teeth_web_TeethWebPortlet";

}