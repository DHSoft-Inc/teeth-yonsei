// treatment.js
// DOMContentLoaded 시 실행하도록 변경하여 INITIAL_TEETHS가 정의된 이후에 코드가 실행되도록 함
document.addEventListener('DOMContentLoaded', () => {
  // JSP에서 정의된 전역 변수 INITIAL_TEETHS 읽기
  const teethsParam = (window.INITIAL_TEETHS || '').trim();
  const passedTeethNames = teethsParam
    .split(',')
    .map(num => 'Teeth' + num.trim())
    .filter(name => name !== 'Teeth' && name !== '');

  // imageWrapper 숨김 (필요 시)
  const imageWrapper = document.getElementById('imageWrapper');
  if (imageWrapper) {
    imageWrapper.style.display = 'none';
  }

  // 주요 DOM 요소 캐싱
  const jointNumLabel = document.getElementById('jointNumLabel');
  const selectedButtonsLabel = document.getElementById('selectedButtonsLabel');
  const historyContainer = document.getElementById('historyContainer');
  const patientImage = document.getElementById('patientImage');
  const treatmentDateInput = document.getElementById('treatmentDate');
  const addBtn = document.getElementById('addTreatmentBtn');
  const statusRadios = Array.from(document.querySelectorAll('input[name="status"]'));
  const permanent = document.querySelector('input[name="permanent"]')?.value;
  
  console.log('permanent:', permanent);
  
  // 초기 선택 개수
  let jointNum = passedTeethNames.length;

  // regions 정의 (기존 좌표 배열 그대로 복사)
  const regions = [ /* 기존 regions 좌표 배열 복사 */ ];

  // 넘어온 teeths에 해당하는 region만 선택 상태로 설정
  regions.forEach(r => {
    r.isClicked = passedTeethNames.includes(r.name);
  });

  // 선택된 영역 시각화 (이벤트 제외)
  regions.forEach(region => {
    const div = document.createElement('div');
    div.classList.add('region');
    div.dataset.name = region.name;
    imageWrapper && imageWrapper.appendChild(div);
  });

  // 이력 표시 함수
  function updateHistoryDisplay() {
    historyContainer.innerHTML = '';
    regions.filter(r => r.isClicked).forEach(region => {
      const entries = [...region.history].sort((a, b) => b.visit_date - a.visit_date);
      const header = document.createElement('h4');
      header.textContent = region.name;
      historyContainer.appendChild(header);
      const ul = document.createElement('ul');
      entries.forEach(e => {
        const li = document.createElement('li');
        li.textContent = `${e.visit_date.toLocaleDateString()} - ${e.category || ''} ${e.status}`;
        ul.appendChild(li);
      });
      historyContainer.appendChild(ul);
    });
  }

  // drawRegions: 크기 및 색상 업데이트
  function drawRegions() {
    const scaleX = patientImage.clientWidth / patientImage.naturalWidth;
    const scaleY = patientImage.clientHeight / patientImage.naturalHeight;

    regions.forEach(region => {
      const div = document.querySelector(`.region[data-name=\"${region.name}\"]`);
      const left = region.x1 * scaleX;
      const top = region.y1 * scaleY;
      const w = (region.x2 - region.x1) * scaleX;
      const h = (region.y2 - region.y1) * scaleY;
      Object.assign(div.style, { left: `${left}px`, top: `${top}px`, width: `${w}px`, height: `${h}px` });
      div.style.backgroundColor = region.isClicked ? 'red' : (region.history.length ? 'orange' : 'white');
    });

    jointNumLabel.textContent = jointNum;
    selectedButtonsLabel.textContent = passedTeethNames.join(', ');
    updateHistoryDisplay();
  }

  // 초기 렌더링
  if (patientImage.complete) {
    drawRegions();
  } else {
    patientImage.addEventListener('load', drawRegions);
  }
  window.addEventListener('resize', drawRegions);

  // 라디오 선택 시 버튼 활성화
  statusRadios.forEach(radio => {
    radio.addEventListener('change', () => { addBtn.disabled = false; });
  });

  // Add Treatment 클릭
  addBtn.addEventListener('click', () => {
    const selectedStatus = statusRadios.find(r => r.checked)?.value;
    const mainCategory = document.querySelector('input[name=\"mainCategory\"]:checked')?.value;
    const treatmentDate = treatmentDateInput.value ? new Date(treatmentDateInput.value) : new Date();

    // history 업데이트
    regions.forEach(region => {
      if (region.isClicked) {
        if (selectedStatus === 'Cancel') region.history = [];
        else region.history.push({ visit_date: treatmentDate, category: mainCategory, status: selectedStatus });
      }
    });

    // 서버 저장
    const formData = new URLSearchParams({
      EditUserId: Liferay.ThemeDisplay.getUserId(),
      treatmentDate: treatmentDate.toISOString().split('T')[0],
      mainCategory,
      selectedStatus,
      selectedTeeth: teethsParam,
      permanent, 
      p_auth: Liferay.authToken
    });
    
    $.ajax({
    	  type: 'POST',
    	  url: '/o/teeth-web/ajax/save_treatment_db.jsp',
    	  data: formData.toString(),
    	  contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
    	  success: function(response) {
    	    console.log("서버 응답:", response);
    	  },
    	  error: function(xhr, status, error) {
    	    console.error("AJAX 실패:", error);
    	  }
    	});
    

    // 테이블 업데이트
    const tbody = document.querySelector('#treatmentTable tbody');
    const tr = document.createElement('tr');
    
    
    const teethNumbers = teethsParam.split(',');
    
    
    teethNumbers.forEach(teethNumber => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td style="border:1px solid #ccc; padding:6px;">${treatmentDate.toLocaleDateString()}</td>
            <td style="border:1px solid #ccc; padding:6px;">${mainCategory}</td>
            <td style="border:1px solid #ccc; padding:6px;">${selectedStatus}</td>
            <td style="border:1px solid #ccc; padding:6px;">${teethNumber}</td>
            <td style="border:1px solid #ccc; padding:6px;">${permanent}</td>
            <td style="border:1px solid #ccc; padding:6px; text-align:center;">
                <button type="button" class="clear-btn">Clear</button>
            </td>
        `;
        tbody.appendChild(tr);
        
        // clear-btn 클릭 시 처리
        const clearBtn = tr.querySelector('.clear-btn');
        clearBtn.addEventListener('click', () => {
            // 1) 화면에서 행 제거
            tr.remove();
            
            // 2) 삭제할 정보 추출
            const deleteData = new URLSearchParams({
                EditUserId: Liferay.ThemeDisplay.getUserId(),
                treatmentDate: tr.children[0].textContent.trim(), // 날짜
                mainCategory: tr.children[1].textContent.trim(),  // 대분류
                selectedStatus: tr.children[2].textContent.trim(), // 상태
                selectedTeeth: tr.children[3].textContent.trim(),  // 치아번호
            });

            // 3) ajax로 해당 행 정보 전송 → 서버에서 삭제 처리
            $.ajax({
                type: 'POST',
                url: '/o/teeth-web/ajax/delete_treatment_db.jsp',
                data: deleteData.toString(),
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                success: function(response) {
                    console.log("서버 응답:", response);
                },
                error: function(xhr, status, error) {
                    console.error("AJAX 실패:", error);
                }
            });
    });

   
    });
    
    // 리셋
    statusRadios.forEach(r => r.checked = false);
    addBtn.disabled = true;
    drawRegions();
  });
});
