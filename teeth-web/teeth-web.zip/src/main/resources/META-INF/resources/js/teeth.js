// 즉시 실행 함수(IIFE)로 전역 오염 방지
(() => {
  let jointNum = 0;
  const jointNumLabel = document.getElementById('jointNumLabel');
  const selectedButtonsLabel = document.getElementById('selectedButtonsLabel');
  const historyContainer = document.getElementById('historyContainer');
  const patientImage = document.getElementById('patientImage');
  const imageWrapper = document.getElementById('imageWrapper');

  // 각 region에 history 필드를 추가 (초기값 빈 배열)
  const regions = [
	  { name: 'Teeth11', x1: 1202, y1: 207,  x2: 1357, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth12', x1: 1047, y1: 207,  x2: 1202, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth13', x1:  892, y1: 207,  x2: 1047, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth14', x1:  737, y1: 207,  x2:  892, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth15', x1:  582, y1: 207,  x2:  737, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth16', x1:  427, y1: 207,  x2:  582, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth17', x1:  272, y1: 207,  x2:  427, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth18', x1:  117, y1: 207,  x2:  272, y2: 340,  isClicked: false, history: [] },

	  { name: 'Teeth21', x1: 1440, y1: 207,  x2: 1595, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth22', x1: 1595, y1: 207,  x2: 1750, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth23', x1: 1750, y1: 207,  x2: 1905, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth24', x1: 1905, y1: 207,  x2: 2060, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth25', x1: 2060, y1: 207,  x2: 2215, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth26', x1: 2215, y1: 207,  x2: 2370, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth27', x1: 2370, y1: 207,  x2: 2525, y2: 340,  isClicked: false, history: [] },
	  { name: 'Teeth28', x1: 2525, y1: 207,  x2: 2680, y2: 340,  isClicked: false, history: [] },

	  { name: 'Teeth31', x1: 1440, y1: 1426, x2: 1595, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth32', x1: 1595, y1: 1426, x2: 1750, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth33', x1: 1750, y1: 1426, x2: 1905, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth34', x1: 1905, y1: 1426, x2: 2060, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth35', x1: 2060, y1: 1426, x2: 2215, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth36', x1: 2215, y1: 1426, x2: 2370, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth37', x1: 2370, y1: 1426, x2: 2525, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth38', x1: 2525, y1: 1426, x2: 2680, y2: 1559, isClicked: false, history: [] },

	  { name: 'Teeth41', x1: 1202, y1: 1426, x2: 1357, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth42', x1: 1047, y1: 1426, x2: 1202, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth43', x1:  892, y1: 1426, x2: 1047, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth44', x1:  737, y1: 1426, x2:  892, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth45', x1:  582, y1: 1426, x2:  737, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth46', x1:  427, y1: 1426, x2:  582, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth47', x1:  272, y1: 1426, x2:  427, y2: 1559, isClicked: false, history: [] },
	  { name: 'Teeth48', x1:  117, y1: 1426, x2:  272, y2: 1559, isClicked: false, history: [] },

	  { name: 'Teeth51', x1: 1202, y1: 612,  x2: 1357, y2: 745,  isClicked: false, history: [] },
	  { name: 'Teeth52', x1: 1047, y1: 612,  x2: 1202, y2: 745,  isClicked: false, history: [] },
	  { name: 'Teeth53', x1:  892, y1: 612,  x2: 1047, y2: 745,  isClicked: false, history: [] },
	  { name: 'Teeth54', x1:  737, y1: 612,  x2:  892, y2: 745,  isClicked: false, history: [] },
	  { name: 'Teeth55', x1:  582, y1: 612,  x2:  737, y2: 745,  isClicked: false, history: [] },

	  { name: 'Teeth61', x1: 1440, y1: 612,  x2: 1595, y2: 745,  isClicked: false, history: [] },
	  { name: 'Teeth62', x1: 1595, y1: 612,  x2: 1750, y2: 745,  isClicked: false, history: [] },
	  { name: 'Teeth63', x1: 1750, y1: 612,  x2: 1905, y2: 745,  isClicked: false, history: [] },
	  { name: 'Teeth64', x1: 1905, y1: 612,  x2: 2060, y2: 745,  isClicked: false, history: [] },
	  { name: 'Teeth65', x1: 2060, y1: 612,  x2: 2215, y2: 745,  isClicked: false, history: [] },

	  { name: 'Teeth71', x1: 1440, y1: 1017, x2: 1595, y2: 1150, isClicked: false, history: [] },
	  { name: 'Teeth72', x1: 1595, y1: 1017, x2: 1750, y2: 1150, isClicked: false, history: [] },
	  { name: 'Teeth73', x1: 1750, y1: 1017, x2: 1905, y2: 1150, isClicked: false, history: [] },
	  { name: 'Teeth74', x1: 1905, y1: 1017, x2: 2060, y2: 1150, isClicked: false, history: [] },
	  { name: 'Teeth75', x1: 2060, y1: 1017, x2: 2215, y2: 1150, isClicked: false, history: [] },

	  { name: 'Teeth81', x1: 1202, y1: 1017, x2: 1357, y2: 1150, isClicked: false, history: [] },
	  { name: 'Teeth82', x1: 1047, y1: 1017, x2: 1202, y2: 1150, isClicked: false, history: [] },
	  { name: 'Teeth83', x1:  892, y1: 1017, x2: 1047, y2: 1150, isClicked: false, history: [] },
	  { name: 'Teeth84', x1:  737, y1: 1017, x2:  892, y2: 1150, isClicked: false, history: [] },
	  { name: 'Teeth85', x1:  582, y1: 1017, x2:  737, y2: 1150, isClicked: false, history: [] }
	];
  
  //JSP 에서 전달된 historyMap 을 전역으로 사용
  //(historyMap 은 teethview.jsp 에서 정의됨)
  regions.forEach(r => {
	  // JS 객체로 넘어온 경우, r.history 에 대입
	  if (typeof historyMap === 'object' && historyMap !== null) {
		    r.history = historyMap[r.name] || [];
		  } else {
		    r.history = [];
		  }
  });
  
  // DIV 생성 및 클릭 토글
  regions.forEach(region => {
    const div = document.createElement('div');
    div.classList.add('region');
    div.dataset.name = region.name;
    div.addEventListener('click', e => {
      e.stopPropagation();
      region.isClicked = !region.isClicked;
      jointNum += region.isClicked ? 1 : -1;
      drawRegions();
    });
    imageWrapper.appendChild(div);
  });

  // 드래그 선택 기능
  let isDragging = false;
  let dragStartX = 0;
  let dragStartY = 0;
  let selectionBox = null;

  imageWrapper.addEventListener('mousedown', e => {
    if (e.target !== imageWrapper && e.target !== patientImage) return;
    e.preventDefault();
    isDragging = true;
    const rect = imageWrapper.getBoundingClientRect();
    dragStartX = e.clientX - rect.left;
    dragStartY = e.clientY - rect.top;
    selectionBox = document.createElement('div');
    Object.assign(selectionBox.style, {
      position: 'absolute',
      border: '1px dashed #000',
      backgroundColor: 'rgba(0,0,255,0.2)',
      pointerEvents: 'none'
    });
    imageWrapper.appendChild(selectionBox);
  });

  window.addEventListener('mousemove', e => {
    if (!isDragging || !selectionBox) return;
    const rect = imageWrapper.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const left = Math.min(x, dragStartX);
    const top = Math.min(y, dragStartY);
    const width = Math.abs(x - dragStartX);
    const height = Math.abs(y - dragStartY);
    Object.assign(selectionBox.style, {
      left: left + 'px',
      top: top + 'px',
      width: width + 'px',
      height: height + 'px'
    });
  });

  window.addEventListener('mouseup', e => {
    if (!isDragging) return;
    isDragging = false;
    const rect = imageWrapper.getBoundingClientRect();
    const endX = e.clientX - rect.left;
    const endY = e.clientY - rect.top;
    const selX = Math.min(endX, dragStartX);
    const selY = Math.min(endY, dragStartY);
    const selW = Math.abs(endX - dragStartX);
    const selH = Math.abs(endY - dragStartY);
    if (selectionBox) {
      selectionBox.remove();
      selectionBox = null;
    }
    regions.forEach(region => {
      const div = imageWrapper.querySelector(`.region[data-name=\"${region.name}\"]`);
      const left = parseFloat(div.style.left);
      const top = parseFloat(div.style.top);
      const w = parseFloat(div.style.width);
      const h = parseFloat(div.style.height);
      if (left + w >= selX && left <= selX + selW && top + h >= selY && top <= selY + selH) {
        region.isClicked = !region.isClicked;
        jointNum += region.isClicked ? 1 : -1;
      }
    });
    drawRegions();
  });


  // 이력 표시 업데이트
  function updateHistoryDisplay() {
	  historyContainer.innerHTML = '';

	  regions.filter(r => r.history.length).forEach(region => {
	    const header = document.createElement('h4');
	    header.textContent = region.name;
	    historyContainer.appendChild(header);

	    //선택된 region 객체들만 걸러낸 뒤
	    const clickedRegions = regions.filter(r => r.isClicked);
	    
	    // names 배열로
	    const clickedNames = clickedRegions.map(r => r.name);
	    
	    // 만약 '11', '14'처럼 순수 숫자만 뽑고 싶다면
	    const clickedNums = clickedNames.map(name => name.replace('Teeth', ''));
	    
	    console.log(clickedNames);
	    console.log(clickedNums);
	    
	    $.ajax({
	    	  type: 'POST',
	    	  url: '/o/teeth-web/ajax/save_teeth_selection.jsp',
	    	  data: { teeths: clickedNums.join(',') },
	    	  success: function(response) {
	    	    console.log("서버 응답:" + response);
	    	    // 여기에 핵심: 숨겨둔 input 값 갱신
	    	    console.log("합성: " + clickedNums.join(','))
	    	    $teethInput.val( clickedNums.join(',') );
	    	    console.log("결과: " + $teethInput.val());
	    	  },
	    	  error: function(xhr, status, error) {
	    	    console.error("AJAX 실패:", error);
	    	  }
	    	});
	    
	    const ul = document.createElement('ul');
	    // 이미 JSP 단계에서 정렬+마지막 2개만 남겼으므로 그대로 출력
	    region.history.forEach(e => {
	      const li = document.createElement('li');
	      li.textContent = `${e.date} – ${e.treatment}`;
	      ul.appendChild(li);
	    });
	    historyContainer.appendChild(ul);
	    
	    
	    
	  });
	}





  // 그리기 및 상단 레이블 업데이트
  function drawRegions() {
	  const curW = patientImage.clientWidth;
	  const curH = patientImage.clientHeight;
	  const natW = patientImage.naturalWidth;
	  const natH = patientImage.naturalHeight;
	  const scaleX = curW / natW;
	  const scaleY = curH / natH;

	  // (0) 이전 history-label, state-label 제거
	  imageWrapper.querySelectorAll('.history-label, .state-label')
	    .forEach(el => el.remove());

	  regions.forEach(region => {
	    const div = imageWrapper.querySelector(`.region[data-name="${region.name}"]`);

	    // (1) 버튼 위치/크기 계산
	    const left   = region.x1 * scaleX;
	    const top    = region.y1 * scaleY;
	    const width  = (region.x2 - region.x1) * scaleX;
	    const height = (region.y2 - region.y1) * scaleY;

	    Object.assign(div.style, {
	      left:   left + 'px',
	      top:    top  + 'px',
	      width:  width  + 'px',
	      height: height + 'px',
	      backgroundColor: region.isClicked
	        ? 'red'
	        : region.history.length
	          ? 'orange'
	          : 'white'
	    });

	    // (2) 가장 최근 state-label 생성 (버튼 위)
	    if (region.history.length) {
	      const latestState = region.history[region.history.length - 1].state;

	      const stateLbl = document.createElement('div');
	      stateLbl.classList.add('state-label');
	      Object.assign(stateLbl.style, {
	        position:      'absolute',
	        left:          left + 'px',
	        top:           top - 18 + 'px',   // 버튼 바로 위 (18px 위로)
	        width:         width + 'px',
	        textAlign:     'center',
	        fontSize:      '0.8rem',
	        fontWeight:    'bold',
	        pointerEvents: 'none'
	      });
	      stateLbl.textContent = latestState;
	      imageWrapper.appendChild(stateLbl);
	    }

	    // (3) history-label 생성 (이전처럼 버튼 아래)
	    if (region.history.length) {
	      const lbl = document.createElement('div');
	      lbl.classList.add('history-label');
	      Object.assign(lbl.style, {
	        position:      'absolute',
	        left:          left + 'px',
	        top:           top + height + 2 + 'px',
	        width:         width + 'px',
	        textAlign:     'center',
	        fontSize:      '0.8rem',
	        pointerEvents: 'none'
	      });

	      const texts = region.history.slice(-2).map(e => e.treatment);
	      if (region.history.length > 2) texts.push('…');
	      lbl.textContent = texts.join(', ');

	      imageWrapper.appendChild(lbl);
	    }
	  });

	  // (4) 상단 레이블 등 나머지 업데이트
	  jointNumLabel.textContent = jointNum;
	  const teethsStr = regions.filter(r => r.isClicked).map(r => r.name).join(', ');
	  selectedButtonsLabel.textContent = regions
	    .filter(r => r.isClicked)
	    .map(r => r.name)
	    .join(', ');
	  
	  $('teeths').val(teethsStr);
	  
	  updateHistoryDisplay();
	}

  patientImage.addEventListener('load', drawRegions);
  window.addEventListener('resize', drawRegions);
  if (patientImage.complete) drawRegions();


})();

